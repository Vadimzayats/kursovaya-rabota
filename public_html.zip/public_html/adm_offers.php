
<?php
require_once "helpers/function.php";
if (empty($_SESSION['user'])) {
    header("Location: http://vadikzayts.temp.swtest.ru/");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Будмен - заказы</title>
    <link rel ="icon" href="images/logo.jpg">
    <link rel="stylesheet" href="styles\main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Play&display=swap" rel="stylesheet"> 
<style>.table {
	width: 100%;
	border: none;
	margin-bottom: 20px;
	border-collapse: separate;
}
.table thead th {
	font-weight: bold;
	text-align: left;
	border: none;
	padding: 10px 15px;
	background: #EDEDED;
	font-size: 14px;
	border-top: 1px solid #ddd;
}
.table tr th:first-child, .table tr td:first-child {
	border-left: 1px solid #ddd;
}
.table tr th:last-child, .table tr td:last-child {
	border-right: 1px solid #ddd;
}
.table thead tr th:first-child {
	border-radius: 20px 0 0 0;
}
.table thead tr th:last-child {
	border-radius: 0 20px 0 0;
}
.table tbody td {
	text-align: left;
	border: none;
	padding: 10px 15px;
	font-size: 14px;
	vertical-align: top;
}
.table tbody tr:nth-child(even) {
	background: #F8F8F8;
}
.table tbody tr:last-child td{
	border-bottom: 1px solid #ddd;
}
.table tbody tr:last-child td:first-child {
	border-radius: 0 0 0 20px;
}
.table tbody tr:last-child td:last-child {
	border-radius: 0 0 20px 0;
}</style>
</head>
<body>
<header>
    <div class="header">
      <a href="#" class="logo"><img src="../images\mujik.png" alt="mujik"></a>
      
      


        <div class="header-right">
            <a class="novod" href="../news.php">Новости</a>
            <a href="/admpanel/index.php"><p class="novod">Каталог</p></a>
            <a href="#"><p class="ras">Заказы</p></a>

              <div>
                <form action="../exit.php">
                    <button class="book-button">Выйти</button>
                </form>
              </div>
          
        </div>
     
    </div>
  </header>

<main>
  <div class="main-heading">
      <h1><span id="zagol"> Заказы</span></h1>
      <p></p>
    </div>

    
            <div id="click-expand1"></div>
            <div class="wrap-expand-table"> <a id="a1" href="#click-expand1"><button class="btn1" id="button1" >Развернуть</button></a><a id="a1"href="#close"><button class="btn"  id="button2" >Cвернуть</button></a>
            <table class="table">
              <thead>
            <tr> 
              <th>Имя</th>
              <th>email</th>
              <th>Номер</th>
              <th>Сообщения</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach(offerses() as $row) {?>
            <tr>
              <td><?=$row['name']?></td>
              <td><?=$row['email']?></td>
              <td><?=$row['number']?></td>
              <td><?=$row['comment']?></td>
            </tr>
            <?php }?>
            </tbody>
  </table>
  
</div>

 
  

</main>
<footer>
  <div class="footer">
    <div class="row">
      <a href="https://vk.me/join/AJQ1d8CosSI7TcgMB/eW/xQ4"><i class="fa fa-vk"></i></a>
      <a href="https://www.youtube.com/@user-vs2rf9mg8g/featured"><i class="fa fa-youtube"></i></a>
      <a href="https://t.me/c/1940888921/1"><i class="fa fa-telegram"></i></a>
    </div>

    <div class="row">
      <ul>
        <li><a href="#">Связаться с нами</a></li>
        <li><a href="https://translated.turbopages.org/proxy_u/en-ru.ru.7d7bd6a7-65db0850-50656b09-74722d776562/https/en.wikipedia.org/wiki/Privacy_policy">Политика конфиденциальности</a></li>
        <li><a href="#">Правила</a></li>
      </ul>
    </div>

    <div class="row">
    Copyright © 2024 - All rights reserved 
    </div>
  </div>
</footer>







<script  src="scripts/main.js"></script>
<script  src="scripts/script.js"></script>

</body>
</html>