<?php
include('simple_html_dom.php');
require_once('../helpers/function.php');
$name=filter_var(trim($_POST['name'] ?? ""));
$email=filter_var(trim($_POST['email'] ?? ""));
$number=filter_var(trim($_POST['number'] ?? ""));
$comment=filter_var(trim($_POST['comment'] ?? ""));
$html = file_get_html('index.php');
$cost = $html->find('#popup_cost_discount', 0)->innertext;
if($name && $email && $number){
$sql = "INSERT INTO `offers` (name,email,number,comment, cost) VALUES('$name', '$email', '$number', '$comment', '$cost')";
    if ($db -> query($sql) === TRUE){
        header("Location: http://vadikzayts.temp.swtest.ru/admpanel/index.php");
        $db ->close();
    }
    else{
        echo "Ошибка:", $db->error;
    }   
}