<?php
/* сервер идентифицирует браузер */
session_start();
//echo phpinfo();

$db = mysqli_connect("localhost", "vadikzayts", "Aa123456", "vadikzayts");
if (!$db) {
    die('Ошибка подключения');
}

function login($name, $psw, $family)
{
    global $db;
    $result = mysqli_query($db, "SELECT * FROM `users` WHERE name='$name' AND psw=md5('$psw') AND family='$family';");
    return mysqli_num_rows($result);
}
function offerses()
{
    global $db;
    $result = mysqli_query($db, "SELECT  *  FROM `offers`  ;" );
    return mysqli_fetch_all($result, MYSQLI_ASSOC );

}
function offer($name, $email, $number, $comment)
{ 
    global $db;
    $sql = "INSERT INTO `offers` (name,email,number,comment) VALUES('$name', '$email', '$number', '$comment')";
    if ($db -> query($sql) === TRUE){
        header('Location: /');
        $db ->close();
    }
    else{
        echo "Ошибка:", $db->error;
    }   
}