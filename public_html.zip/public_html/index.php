<?php
require_once "helpers/function.php";
if (!empty($_SESSION['user'])) {
    header("Location: /admpanel/index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Каталог</title>
    <link rel ="icon" href="images/logo.jpg">
    <link rel="stylesheet" href="styles\main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Play&display=swap" rel="stylesheet"> 
<style>
	.skidonchik{
width:100%;
}	
   </style>
</head>
<body>
    

  <header>
        <div class="-">
              <div style="float: right; ; margin-top:0%; margin-right:2.5% ; padding: 20px 60px; border-radius: 100px;">
                <form action="singin.php">
                    <button class="book-button" style="padding: 20px 60px; border-radius: 100px; "><b>Войти</b></button>
                </form>
              </div>
          
        </div>
    <div class="skidonchik">
    <img src="../images/skidonchik.png">
  </div>
  </header>

        <section class="product">
      <div class="product__info">
        <div class="container">
          <h1 class="product__title">Каталог</h1>
          <h1 class="product__title product__title--gray">8 товаров</h1>
        </div>
      </div>
      <div class="cards">
        <div class="card">
          <div class="card__top">
            <a href="#" class="card__image">
              <img
                src="./images/fanera.webp"
                alt="Фанера"
              />
            </a>
            <div class="card__label">-10%</div>
          </div>
          <div class="card__bottom">
            <div class="card__prices">
              <div class="card__price card__price--discount">758</div>
              <div class="card__price card__price--common">843</div>
            </div>
            <a href="#" class="card__title">
              Фанера 10мм нешлифованная 1525х1525 мм ФК сорт 4/4
            </a>
            <button class="card__add">В корзину</button>
          </div>
        </div>
        <div class="card">
          <div class="card__top">
            <a href="#" class="card__image">
              <img
                src="./images/Laminat.webp"
                alt="Ламинат"
              />
            </a>
            <div class="card__label">-10%</div>
          </div>
          <div class="card__bottom">
            <div class="card__prices">
              <div class="card__price card__price--discount">337</div>
              <div class="card__price card__price--common">374</div>
            </div>
            <a href="#" class="card__title">
              Ламинат "Дуб Хадсон" 31 класс толщина 6 мм 2.691 м
            </a>
            <button class="card__add">В корзину</button>
          </div>
        </div>
        <div class="card">
          <div class="card__top">
            <a href="#" class="card__image">
              <img
                src="./images/Cement.webp"
                alt="Цемент"
              />
            </a>
            <div class="card__label">-10%</div>
          </div>
          <div class="card__bottom">
            <div class="card__prices">
              <div class="card__price card__price--discount">311</div>
              <div class="card__price card__price--common">345</div>
            </div>
            <a href="#" class="card__title">
              Цемент Цемрос М500 ЦЕМ I 42.5 Н 25 кг
            </a>
            <button class="card__add">В корзину</button>
          </div>
        </div>
        <div class="card">
          <div class="card__top">
            <a href="#" class="card__image">
              <img
                src="./images/Plita.webp"
                alt="Плита гипсовая"
              />
            </a>
            <div class="card__label">-10%</div>
          </div>
          <div class="card__bottom">
            <div class="card__prices">
              <div class="card__price card__price--discount">269</div>
              <div class="card__price card__price--common">298</div>
            </div>
            <a href="#" class="card__title">
              Плита гипсовая пазогребневая (ПГП) Волма 667х500х80 мм полнотелая
            </a>
            <button class="card__add">В корзину</button>
          </div>
        </div>
        <div class="card">
          <div class="card__top">
            <a href="#" class="card__image">
              <img
                src="./images/Brick.webp"
                alt="Кирпич"
              />
            </a>
            <div class="card__label">-10%</div>
          </div>
          <div class="card__bottom">
            <div class="card__prices">
              <div class="card__price card__price--discount">11.70</div>
              <div class="card__price card__price--common">13</div>
            </div>
            <a href="#" class="card__title">
              Кирпич строительный рядовой пустотелый Volgabrick M200 250x120x65 мм 1 НФ
            </a>
            <button class="card__add">В корзину</button>
          </div>
        </div>
        <div class="card">
          <div class="card__top">
            <a href="#" class="card__image">
              <img
                src="./images/Kraska.webp"
                alt="Краска"
              />
            </a>
            <div class="card__label">-10%</div>
          </div>
          <div class="card__bottom">
            <div class="card__prices">
              <div class="card__price card__price--discount">2124</div>
              <div class="card__price card__price--common">2360</div>
            </div>
            <a href="#" class="card__title">
              Краска для стен Luxens моющаяся матовая белая база А 10 л</a
            >
            <button class="card__add">В корзину</button>
          </div>
        </div>
        <div class="card">
          <div class="card__top">
            <a href="#" class="card__image">
              <img
                src="./images/Door.webp"
                alt="Входная дверь"
              />
            </a>
            <div class="card__label">-10%</div>
          </div>
          <div class="card__bottom">
            <div class="card__prices">
              <div class="card__price card__price--discount">35 550</div>
              <div class="card__price card__price--common">39 500</div>
            </div>
            <a href="#" class="card__title">
              Входная дверь Bunker Графит правый 205х96см зеркало ФЛЗ-618 белый софт/лофт графит</a
            >
            <button class="card__add">В корзину</button>
          </div>
        </div>
        <div class="card">
          <div class="card__top">
            <a href="#" class="card__image">
              <img
                src="./images/Radiator.webp"
                alt="Радиатор отопления"
              />
            </a>
            <div class="card__label">-10%</div>
          </div>
          <div class="card__bottom">
            <div class="card__prices">
              <div class="card__price card__price--discount">4 339</div>
              <div class="card__price card__price--common">4 821</div>
            </div>
            <a href="#" class="card__title">
              Радиатор Monlan Bimetal 500/80 биметалл 10 секций боковое подключение цвет белый</a
            >
            <button class="card__add">В корзину</button>
          </div>
        </div>
      </div>
    </section>
    <button class="cart" id="cart">
      <img class="cart__image" src="./images/cart.png" alt="Cart" srcset="" />
      <div class="cart__num" id="cart_num">0</div>
    </button>
    <div class="popup">
      <div class="popup__container" id="popup_container">
        <div class="popup__item">
          <h1 class="popup__title">Оформление заказа</h1>
        </div>
        <div class="popup__item" id="popup_product_list">
          <div class="popup__product">
            <div class="popup__product-wrap">
              <img
                src="./images/fanera.webp"
                alt="Фанера"
                class="popup__product-image"
              />
              <h2 class="popup__product-title">
                Фанера
              </h2>
            </div>
            <div class="popup__product-wrap">
              <div class="popup__product-price">758</div>
              <button class="popup__product-delete">&#10006;</button>
            </div>
          </div>
        </div>
        <div class="popup__item">
          <div class="popup__cost">
            <h2 class="popup__cost-title">Итого</h2>
            <output class="popup__cost-value" id="popup_cost">0</output>
          </div>
          <div class="popup__cost">
            <h2 class="popup__cost-title">Скидка</h2>
            <output class="popup__cost-value" id="popup_discount">0</output>
          </div>
          <div class="popup__cost">
            <h2 class="popup__cost-title">Итого со скидкой</h2>
            <output class="popup__cost-value" id="popup_cost_discount"
              >0</output
            >
          </div>
        </div>
        <button class="popup__close" id="popup_close">&#10006;</button>
            <!-- Контейнер выравнивает по ширине и по центру -->
    <div class="container">

      <!-- content содержит содержимое формы -->
      <div class="content">

        <!-- Левая колонка: адрес, телефоны, email. Можете добавить свое -->
        <div class="left-side">
          <div class="address details">

            <!-- Вместо классов: название шрифтовых иконок (fontawesome.com) -->
            <i class="fas fa-map-marker-alt"></i>

            <!-- topic - заголовок, text-one, text-two - текст -->
            <div class="topic">Адрес</div>
            <div class="text-one">г. Люберцы</div>
            <div class="text-two">Октябрьский проспект, 21</div>
          </div>
          <div class="phone details">
            <i class="fas fa-phone-alt"></i>
            <div class="topic">Телефон</div>
            <div class="text-one">8-800-000-00-00</div>
            <div class="text-two">8-900-000-00-00</div>
          </div>
          <div class="email details">
            <i class="fas fa-envelope"></i>
            <div class="topic">Email</div>
            <div class="text-one">support@site.com</div>
            <div class="text-two">admin@site.com</div>
          </div>
        </div>

        <!-- Правая колонка: сама форма -->
        <div class="right-side">

          <!-- Заголовок для формы -->
          <div class="topic-text">Оформление заказа</div>

          <!-- Какой-то дополнительный текст -->
          <p>
          Для оформления заказа оставьте свои данные в формах ниже. Оформление заказа недоступно для незарегистрированных пользователей
          </p>

          <!-- Форма обратной связи -->
          <form action="#">

            <!-- Каждый input для выравнивания вкладываем в блок input-box -->
            <div class="input-box">
              <input type="text" placeholder="Ваше имя" />
            </div>
            <div class="input-box">
              <input type="text" placeholder="Введите email" />
            </div>
            <div class="input-box">
              <input type="text" placeholder="Введите телефон" />
            </div>
            <div class="input-box message-box">
              <textarea placeholder="Сообщение"></textarea>
            </div>
            <div class="button">

              <input type="button" value="Отправить">
            </div>
          </form>
        </div>
      </div>
    </div>
      </div>
    </div>
    <script src="./scripts/main.js"></script>
    <script src="https://kit.fontawesome.com/fce9a50d02.js"crossorigin="anonymous"></script>

  </body>
  <footer>
    <div class="footer">
      <div class="row">
        <a href="https://vk.me/join/AJQ1d8CosSI7TcgMB/eW/xQ4"><i class="fa fa-vk"></i></a>
        <a href="https://t.me/c/1940888921/1"><i class="fa fa-telegram"></i></a>
      </div>

      <div class="row">
        <ul>
          <li><a href="#">Связаться с нами</a></li>
          <li><a href="#">Политика конфиденциальности</a></li>
          <li><a href="#">Правила</a></li>
        </ul>
      </div>

      <div class="row">
      Copyright © 2024 - All rights reserved 
      </div>
    </div>
  </footer>

  





  <script  href="scripts\main.js"></script>
</body>
</html>