<?php
require_once "helpers/function.php";
if (empty($_SESSION['user'])) {
    header("Location: http://vadikzayts.temp.swtest.ru");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Будмен - новости</title>
    <link rel ="icon" href="../images/logo.jpg">
    <link rel="stylesheet" href="../styles\main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Play&display=swap" rel="stylesheet"> 

</head>
<body>
<header>
    <div class="header">
      <a href="http://vadikzayts.temp.swtest.ru/admpanel" class="logo"><img src="images\mujik.png" alt="mujik"></a>
      
      


        <div class="header-right">
            <a  href="news.php"><p class="ras">Новости </p></a>
            <a class="novod" href="http://vadikzayts.temp.swtest.ru/admpanel">Каталог</a>
              <div>
                <form action="exit.php">
                    <button class="book-button">Выйти</button>
                </form>
              </div>
          
        </div>
     
    </div>


    <div class="main-heading">
      <h1><span id="zagol">Новостной блок</span></h1>
      <p></p>
    </div>
  </header>

<main>
<div class="slider"></div>
  
</main>
<footer>
  <div class="footer">
    <div class="row">
        <a href="#"><i class="fa fa-vk"></i></a>
        <a href="#"><i class="fa fa-telegram"></i></a>
    </div>

    <div class="row">
      <ul>
        <li><a href="#">Связаться с нами</a></li>
        <li><a href="#">Политика конфиденциальности</a></li>
        <li><a href="#">Правила</a></li>
      </ul>
    </div>

    <div class="row">
    Copyright © 2024 - All rights reserved 
    </div>
  </div>
</footer>







<script  href="scripts/main.js"></script>
</body>
</html>