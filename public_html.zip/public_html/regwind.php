<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Будмен - регистрация</title>
    <link rel ="icon" href="images/logo.jpg">
    <link rel="stylesheet" href="styles\main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Play&display=swap" rel="stylesheet"> 

</head>
<body>
    <form action="register.php" method="post">
        <div class="container">
          <h1 class="reg_wind_text_higth">Регистрация</h1>
          <p class="reg_wind_text_higth">Пожалуйста, заполните эту форму, чтобы создать учетную запись.</p>

          <div class="pole_reg">
          
      
          <label class="reg_wind_text" for="name"></label>
          <input type="text" placeholder="Введите имя" name="name" required>
            <br>
          <label class="reg_wind_text" for="family"></label>
          <input type="text" placeholder="Введите фамилию" name="family" required>
          <br>
          <label class="reg_wind_text" for="psw"></label>
          <input type="text" placeholder="Введите пароль" name="psw" required>
          <br>
          <label class="reg_wind_text" for="psw_repeat"></label>
          <input type="text" placeholder="Повторите пароль" name="psw_repeat" required>
          </div>

      
         
          
        </div>
      
        <div class="container signin">
          <p class="reg_wind_text">Создавая учетную запись, вы соглашаетесь с нашими <a href="https://ru.wikipedia.org/wiki/Конфиденциальность">Условия и конфиденциальность</a>.</p>
          <p class="reg_wind_text">У вас уже есть учетная запись? <a href="singin.php">Войти</a>.</p>
        </div>
        <button type="submit" class="registerbtn">Зарегистрироваться</button>
      </form>
</body>
</html>