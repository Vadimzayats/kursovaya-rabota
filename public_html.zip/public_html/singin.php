<?php
require_once "helpers/function.php";
if (!empty($_SESSION['user'])) {
    header("Location: http://vadikzayts.temp.swtest.ru/admpanel/index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Будмен - войти</title>
    <link rel ="icon" href="images/logo.jpg">
    <link rel="stylesheet" href="styles\main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Play&display=swap" rel="stylesheet"> 

</head>
<body>
    <form class="otverh">
        <div class="container">
          <h1 class="reg_wind_text_higth">Войти</h1>
          <p class="reg_wind_text_higth">Пожалуйста, заполните эту форму, чтобы зайти в аккаунт</p>
          <div class="pole_reg">
          <?php
          $name = strip_tags($_GET['name'] ?? "");
          $family=strip_tags($_GET['family'] ?? "");
          $psw = strip_tags($_GET['psw'] ?? "");
              if ($name && $psw && $family) {
                  if (login($name, $psw, $family)) {
                      header("Location: http://vadikzayts.temp.swtest.ru/admpanel");
                      $_SESSION['user'] = $name;
                  } else {
                      echo "<script language='javascript'> 
                          alert('Нет такого пользователя')
                          </script> 
                          ";
                      
                  }
              }
        ?>      
      
          <label class="reg_wind_text" for="name"></label>
          <input type="text" placeholder="Введите имя" name="name" required>
            <br>
          <label class="reg_wind_text" for="family"></label>
          <input type="text" placeholder="Введите фамилию" name="family" required>
          <br>
          <label class="reg_wind_text" for="psw"></label>
          <input type="text" placeholder="Введите пароль" name="psw" required>
          
         
          
        </div>
        <div class="container signin">
          <p class="reg_wind_text">У вас еще нет аккаунта? <a href="regwind.php">Зарегистрироваться</a>.</p>
        </div>
      
        <button type="submit" class="registerbtn">Войти</button>
      </form>
</body>
</html>